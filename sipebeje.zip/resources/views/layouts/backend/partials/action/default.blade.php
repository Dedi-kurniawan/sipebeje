<button id="editData" data-id="{{ $id }}" data-name="{{ $name }}" class="btn btn-sm btn-outline-success">
    <i class="fa fa-pen"></i> Ubah
</button>
<button id="deleteData" data-id="{{ $id }}" data-name="{{ $name }}" class="btn btn-sm btn-outline-danger">
    <i class="fa fa-trash"></i> Hapus
</button>