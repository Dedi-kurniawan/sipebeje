<button id="editData" data-id="{{ $id }}" data-name="{{ $name }}" class="btn btn-sm btn-outline-success">
    <i class="flaticon2-pen"></i> Ubah
</button>
<button id="deleteData" data-id="{{ $id }}" data-name="{{ $name }}" class="btn btn-sm btn-outline-danger">
    <i class="flaticon-delete"></i> Hapus
</button>