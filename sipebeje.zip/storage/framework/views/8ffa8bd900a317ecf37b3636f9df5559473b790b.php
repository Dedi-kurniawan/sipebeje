
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title text-uppercase small"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title text-uppercase">FORMULIR HARGA PERKIRAAN KERJA (HPS)</h4>
                    <p class="mb-3"><?php echo e($edit->nama); ?></p>
                    <div id="rootwizard">
                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-3">
                            <?php echo $__env->make('backend.paket._tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                        <div class="tab-content mb-0 b-0 pt-0">
                            <div class="mb-3 d-flex">
                                <button class="btn btn-success width-md waves-effect waves-light float-end" onclick="createData()">
                                     <i class="fe-plus"></i> TAMBAH HPS
                                </button>
                                <input type="hidden" value="<?php echo e($edit->id); ?>" id="paket_id_value">
                            </div>
                            <div class="tab-pane <?php echo e($tab == "hps" ? "active" : ""); ?>" id="first">
                                <div class="table-responsive">
                                    <table id="datatable" class="table nowrap w-100 mt-3">
                                        <thead>
                                            <tr>
                                                <th>NO</th>
                                                <th>URAIAN</th>
                                                <th>VOLUME</th>
                                                <th>HARGA @</th>
                                                <th>SATUAN</th>
                                                <th>JUMLAH</th>
                                                <th>PAJAK</th>
                                                <th>HARGA SETELAH PAJAK</th>
                                                <th>KETERANGAN</th>
                                                <th>AKSI</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                                <div class="mt-3">
                                    <a href="<?php echo e(route('admin.akk.edit', $edit->id)); ?>" class="btn btn-info width-md waves-effect waves-light">
                                        <i class="fe-arrow-left"></i> KERANGKA ACUAN KERJA (KAK)
                                    </a>
                                    <?php if($edit->akk_field == "1"): ?>
                                        <a target="_blank" href="<?php echo e(route('admin.print-hps', $edit->id)); ?>" class="btn btn-warning width-md waves-effect waves-light text-white">
                                            <i class="fa fa-download"></i> DOWNLOAD
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('admin.undangan.edit', $edit->id)); ?>" class="btn btn-primary width-md waves-effect waves-light float-end">
                                         UNDANGAN <i class="fe-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('backend.paket._hps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/mask/dist/jquery.mask.js')); ?>"></script>
<script src="<?php echo e(asset('template/barangjasa/admin/hps.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/paket/hps.blade.php ENDPATH**/ ?>