
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title text-uppercase"> BERITA ACARA EVALUASI HARGA </h4>
                    <p class="mb-3"><?php echo e($paket->nama); ?></p>

                    <div id="rootwizard">
                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-3">
                            <?php echo $__env->make('backend.paket.stepdua._tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                        <div class="tab-content mb-0 b-0 pt-0">
                            <div class="tab-pane <?php echo e($tab == "evaluasi-penawaran" ? "active" : ""); ?>" id="first">
                                <form id="form_validate" method="POST" action="<?php echo e(route('admin.evaluasi-penawaran.update', $paket->id)); ?>" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Nomor surat BA Evaluasi Harga:<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('nomor') ? 'is-invalid' : ''); ?>" maxlength="100" autocomplete="off" name="nomor" value="<?php echo e(old('nomor', $paket->evaluasiPenawaran->nomor)); ?>"  id="nomor" title="kolom nomor di larang kosong" placeholder="Nomor surat BA Evaluasi Harga..." required/>
                                                <?php echo $errors->first('nomor', '<label id="nomor-error" class="error invalid-feedback" for="nomor">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Kegiatan:<span class="text-danger">*</span></label>
                                                <textarea name="kegiatan" class="form-control <?php echo e($errors->has('kegiatan') ? 'is-invalid' : ''); ?>" cols="30" rows="3" disabled placeholder="Kegiatan..." disabled required><?php echo e($paket->evaluasiPenawaran->kegiatan == NULL ? $paket->nama : old('kegiatan', $paket->evaluasiPenawaran->kegiatan)); ?></textarea>
                                                <?php echo $errors->first('kegiatan', '<label id="kegiatan-error" class="error invalid-feedback" for="kegiatan">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Tanggal:<span class="text-danger">*</span></label>
                                                <input type="date" class="form-control <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" maxlength="100" autocomplete="off" name="tanggal" value="<?php echo e(old('tanggal', $paket->evaluasiPenawaran->tanggal)); ?>"  id="tanggal" title="kolom tanggal di larang kosong" placeholder="Nomor..." required/>
                                                <?php echo $errors->first('tanggal', '<label id="tanggal-error" class="error invalid-feedback" for="tanggal">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Jam:<span class="text-danger">*</span></label>
                                                <input type="time" class="form-control <?php echo e($errors->has('jam') ? 'is-invalid' : ''); ?>" autocomplete="off" name="jam" value="<?php echo e(old('jam', $paket->evaluasiPenawaran->jam)); ?>"  id="jam" title="kolom jam di larang kosong" required/>
                                                <?php echo $errors->first('jam', '<label id="jam-error" class="error invalid-feedback" for="jam">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Nomor SK TPK Kepala Desa:<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('nomor_sk') ? 'is-invalid' : ''); ?>" maxlength="100" autocomplete="off" name="nomor_sk" value="<?php echo e(old('nomor_sk', $paket->evaluasiPenawaran->nomor_sk)); ?>"  id="nomor_sk" title="kolom nomor_sk di larang kosong" placeholder="Nomor..." required/>
                                                <?php echo $errors->first('nomor_sk', '<label id="nomor_sk-error" class="error invalid-feedback" for="nomor_sk">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Tahun Anggaran<span class="text-danger">*</span></label>
                                                <select name="tahun_anggaran" id="tahun_anggaran" disabled class="form-control selectFormClass <?php echo e($errors->has('tahun_anggaran') ? 'is-invalid' : ''); ?>" required>
                                                    <option value="">TAHUN</option>
                                                    <?php for($i = 2019; $i < date('Y')+5; $i++): ?>
                                                        <option value="<?php echo e($i); ?>" <?php echo e($paket->evaluasiPenawaran->tahun_anggaran == $i ? "selected" : ""); ?>><?php echo e($i); ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                                <?php echo $errors->first('tahun_anggaran', '<label id="tahun_anggaran-error" class="error invalid-feedback" for="tahun_anggaran">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <button type="submit" class="btn btn-info width-md waves-effect waves-light">
                                                   <i class="fa fa-save"></i> SIMPAN
                                                </button>
                                                <a href="<?php echo e(route('admin.hasil-evaluasi-penawaran.edit', $paket->id)); ?>" class="btn btn-primary width-md waves-effect waves-light float-end">
                                                    HASIL EVALUASI PENAWARAN <i class="fe-arrow-right"></i>
                                                 </a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/paket/stepdua/evaluasi_penawaran.blade.php ENDPATH**/ ?>