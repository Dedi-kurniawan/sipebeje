
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-titl text-uppercase"> FORMULIR <?php echo e($bread['second']); ?></h4>
                    <p class="mb-3"><?php echo e($paket->nama); ?></p>

                    <div id="rootwizard">
                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-3">
                            <?php echo $__env->make('backend.paket.stepdua._tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                        <div class="tab-content mb-0 b-0 pt-0">
                            <div class="tab-pane <?php echo e($tab == "nego-harga" ? "active" : ""); ?>" id="first">
                                <form id="form_validate" method="POST" action="<?php echo e(route('admin.nego-harga.update', $paket->id)); ?>" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Nomor Surat Berita Acara Nego Harga:<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('nomor') ? 'is-invalid' : ''); ?>" autocomplete="off" name="nomor" value="<?php echo e(old('nomor', $paket->negoHarga->nomor)); ?>"  id="nomor" title="kolom nomor di larang kosong" placeholder="Nomor..." required/>
                                                <?php echo $errors->first('nomor', '<label id="nomor-error" class="error invalid-feedback" for="nomor">:message</label>'); ?>

                                            </div>
                                            <input type="hidden" class="form-control <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" autocomplete="off" readonly name="tanggal" value="<?php echo e(old('tanggal', empty($paket->negoHarga->tanggal) ? $paket->evaluasiPenawaran->tanggal : $paket->negoHarga->tanggal)); ?>"  id="tanggal" title="kolom tanggal di larang kosong" placeholder="Nomor..." required/>
                                            <input type="hidden" class="form-control <?php echo e($errors->has('pukul') ? 'is-invalid' : ''); ?>" autocomplete="off" readonly name="pukul" value="<?php echo e(old('pukul', empty($paket->negoHarga->pukul) ? $paket->evaluasiPenawaran->jam : $paket->negoHarga->pukul)); ?>" id="pukul" title="kolom pukul di larang kosong" required />
                                            
                                            <div class="row mb-3">
                                                <div class="col-12">
                                                    <input type="hidden" id="paket_id_value" value="<?php echo e($paket->id); ?>">
                                                    <button type="button" class="btn btn-success btn-md float-end" onclick="createData()">
                                                        <i class="fe-plus"></i> TAMBAH HPS
                                                    </button>
                                                </div>
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table id="datatable" class="table nowrap w-100 mt-3">
                                                            <thead>
                                                                <tr>
                                                                    <th>NO</th>
                                                                    <th>URAIAN</th>
                                                                    <th>VOLUME</th>
                                                                    <th>HARGA SEBELUM PAJAK</th>
                                                                    <th>SATUAN</th>
                                                                    <th>JUMLAH</th>
                                                                    <th>PAJAK</th>
                                                                    <th>HARGA SETELAH PAJAK</th>
                                                                    <th>KETERANGAN</th>
                                                                    <th>AKSI</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody></tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mb-2 fw-bold">
                                                I. Uraian Klarifikasi mengenai
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Uraian Klarifikasi:<span class="text-danger">*</span></label>
                                                <input type="hidden" name="uraian_klarifikasi" id="uraian_klarifikasi" value="<?php echo e(old('uraian_klarifikasi', $paket->negoHarga->uraian_klarifikasi)); ?>">
                                                <div id="editor" style="min-height: 160px;"><?php echo old('uraian_klarifikasi', $paket->negoHarga->uraian_klarifikasi); ?></div>
                                                <?php echo $errors->first('uraian_klarifikasi', '<label id="uraian_klarifikasi-error" class="error invalid-feedback" for="uraian_klarifikasi">:message</label>'); ?>

                                            </div>
                                            <div class="mb-2 fw-bold">
                                                II.	Uraian negosiasi
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Penawaran Rekanan:<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="btn input-group-text btn-dark waves-effect waves-light">Rp. </span>
                                                    <input type="text" class="form-control rupiah <?php echo e($errors->has('penawaran_rekanan') ? 'is-invalid' : ''); ?>" autocomplete="off" name="penawaran_rekanan" value="<?php echo e(old('penawaran_rekanan', $paket->negoHarga->penawaran_rekanan ?? $paket->hps)); ?>" id="penawaran_rekanan" title="kolom penawaran rekanan di larang kosong" placeholder="Penawaran Rekanan..." required />
                                                    <?php echo $errors->first('penawaran_rekanan', '<label id="penawaran_rekanan-error" class="error invalid-feedback" for="penawaran_rekanan">:message</label>'); ?>

                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Penawaran Rekanan (Terbilang):<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control <?php echo e($errors->has('penawaran_rekanan_terbilang') ? 'is-invalid' : ''); ?>" autocomplete="off" name="penawaran_rekanan_terbilang" value="<?php echo e(old('penawaran_rekanan_terbilang', $paket->negoHarga->penawaran_rekanan_terbilang ?? $paket->hps)); ?>" id="penawaran_rekanan_terbilang" title="kolom penawaran rekanan terbilang di larang kosong" placeholder="Penawaran diajukan Terbilang..." required />
                                                    <button class="btn input-group-text btn-dark waves-effect waves-light" type="button" id="penawaran_rekanan_terbilang_rupiah"><i class="fas fa-sync-alt"></i></button>
                                                    <?php echo $errors->first('penawaran_rekanan_terbilang', '<label id="penawaran_rekanan_terbilang-error" class="error invalid-feedback" for="penawaran_rekanan_terbilang">:message</label>'); ?>

                                                </div>
                                                <small class="text-info">Perbaiki secara manual jika terjadi kesalahan</small>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Penawaran diAjukan:<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="btn input-group-text btn-dark waves-effect waves-light">Rp. </span>
                                                    <input type="text" class="form-control rupiah <?php echo e($errors->has('penawaran_diajukan') ? 'is-invalid' : ''); ?>" autocomplete="off" name="penawaran_diajukan" value="<?php echo e(old('penawaran_diajukan', $paket->negoHarga->penawaran_diajukan ?? $paket->hps)); ?>" id="penawaran_diajukan" title="kolom penawaran diajukan di larang kosong" placeholder="Penawaran diajukan..." required />
                                                    <?php echo $errors->first('penawaran_diajukan', '<label id="penawaran_diajukan-error" class="error invalid-feedback" for="penawaran_diajukan">:message</label>'); ?>

                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Penawaran diAjukan (Terbilang):<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control <?php echo e($errors->has('penawaran_diajukan_terbilang') ? 'is-invalid' : ''); ?>" autocomplete="off" name="penawaran_diajukan_terbilang" value="<?php echo e(old('penawaran_diajukan_terbilang', $paket->negoHarga->penawaran_diajukan_terbilang)); ?>" id="penawaran_diajukan_terbilang" title="kolom penawaran diAjukan terbilang di larang kosong" placeholder="Penawaran diajukan Terbilang..." required />
                                                    <button class="btn input-group-text btn-dark waves-effect waves-light" type="button" id="terbilang_rupiah"><i class="fas fa-sync-alt"></i></button>
                                                    <?php echo $errors->first('penawaran_diajukan_terbilang', '<label id="penawaran_diajukan_terbilang-error" class="error invalid-feedback" for="penawaran_diajukan_terbilang">:message</label>'); ?>

                                                </div>
                                                <small class="text-info">Perbaiki secara manual jika terjadi kesalahan</small>
                                            </div>
                                            <div class="mb-2 fw-bold">
                                                III. Kesimpulan
                                            </div>
                                            <?php if($paket->vendor_id == NULL): ?>
                                                <div class="mb-2 fw-bold">
                                                    <label for="example-input-normal" class="form-label text-danger">BELUM ADA PEMENANG DARI TENDER, SILAHKAN TENTUKAN PEMENANG 
                                                        <a href="<?php echo e(route('admin.hasil-evaluasi-penawaran.edit', $paket->id)); ?>">
                                                            HASIL EVALUASI PENAWARAN 
                                                        </a>
                                                    </label>
                                                </div>
                                            <?php endif; ?>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Nama Penyedia: </label>
                                                <span class="fw-bold"> <?php echo e($paket->vendor->nama_perusahaan); ?> </span>
                                                <input type="hidden" name="vendor_id" value="<?php echo e($paket->vendor_id); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Hasil Negosiasi :<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="btn input-group-text btn-dark waves-effect waves-light">Rp. </span>
                                                    <input type="text" class="form-control rupiah <?php echo e($errors->has('hasil_nego') ? 'is-invalid' : ''); ?>" autocomplete="off" name="hasil_nego" value="<?php echo e(old('hasil_nego', $paket->negoHarga->hasil_nego)); ?>" id="hasil_nego" title="kolom hasil negosiasi di larang kosong" placeholder="hasil negosiasi..." required />
                                                    <?php echo $errors->first('hasil_nego', '<label id="hasil_nego-error" class="error invalid-feedback" for="hasil_nego">:message</label>'); ?>

                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Harga Akhir :<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="btn input-group-text btn-dark waves-effect waves-light">Rp. </span>
                                                    <input type="text" class="form-control rupiah <?php echo e($errors->has('harga_final') ? 'is-invalid' : ''); ?>" autocomplete="off" name="harga_final" value="<?php echo e(old('harga_final', $paket->negoHarga->harga_final)); ?>" id="harga_final" title="kolom hasil negosiasi di larang kosong" placeholder="hasil negosiasi..." required />
                                                    <?php echo $errors->first('harga_final', '<label id="harga_final-error" class="error invalid-feedback" for="harga_final">:message</label>'); ?>

                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <button type="submit"class="btn btn-info width-md waves-effect waves-light">
                                                    <i class="fa fa-save"></i> SIMPAN
                                                </button>
                                                <a href="<?php echo e(route('admin.surat-perjanjian.edit', $paket->id)); ?>" class="btn btn-primary width-md waves-effect waves-light float-end">
                                                    SURAT PERJANJIAN <i class="fe-arrow-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('backend.paket._hps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('backend/libs/quill/quill.core.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/quill/quill.bubble.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/quill/quill.snow.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/quill/quill.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/mask/dist/jquery.mask.js')); ?>"></script>
<script src="<?php echo e(asset('template/barangjasa/admin/nego-harga.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/paket/stepdua/nego_harga.blade.php ENDPATH**/ ?>