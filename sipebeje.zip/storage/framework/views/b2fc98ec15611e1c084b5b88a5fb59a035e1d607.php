
<?php $__env->startSection('title', $bread['first']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form id="form_validate" method="POST" action="<?php echo e(route('admin.profile.desa.post')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i> ADMIN DESA</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="firstname" class="form-label">Nama</label>
                                    <input type="text" readonly class="form-control" value="<?php echo e($desa->name); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="lastname" class="form-label">E-mail</label>
                                    <input type="text" readonly class="form-control" value="<?php echo e($desa->email); ?>">
                                </div>
                            </div>
                        </div>
                        <h5 class="mb-3 text-uppercase bg-light p-2"><i class="mdi mdi-office-building me-1"></i> DESA</h5>
                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <label for="nama" class="form-label">Nama Desa <span class="text-danger">*</span></label>
                                    <input type="text" name="nama" class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" readonly id="nama" value="<?php echo e(old('nama', $desa->desa->nama)); ?>" placeholder="Nama perusahaan" required>
                                    <?php echo $errors->first('nama', '<label id="nama-error" class="error invalid-feedback" for="nama">:message</label>'); ?>

                                </div>
                            </div>
                            <div class="col-6">
                                <div class="mb-3">
                                    <label for="kecamatan" class="form-label">Kecamatan <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php echo e($errors->has('kecamatan') ? 'is-invalid' : ''); ?>" readonly id="kecamatan" value="<?php echo e(old('kecamatan', $desa->desa->kecamatan->nama)); ?>" placeholder="Nama perusahaan" required>
                                    <?php echo $errors->first('kecamatan', '<label id="kecamatan-error" class="error invalid-feedback" for="kecamatan">:message</label>'); ?>

                                </div>
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="nama" class="form-label">Kepala Desa <span class="text-danger">*</span></label>
                                <input name="kepala_desa" type="text" class="form-control <?php echo e($errors->has('kepala_desa') ? 'is-invalid' : ''); ?>" id="kepala_desa" value="<?php echo e(old('kepala_desa', $desa->desa->kepala_desa)); ?>" placeholder="Kepala Desa" required>
                                <?php echo $errors->first('kepala_desa', '<label id="kepala_desa-error" class="error invalid-feedback" for="kepala_desa">:message</label>'); ?>

                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="alamat" class="form-label">Alamat</label>
                                <textarea name="alamat" class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid' : ''); ?>" id="alamat" rows="4" placeholder="Alamat..." required><?php echo e(old('alamat', $desa->desa->alamat)); ?></textarea>
                                <?php echo $errors->first('alamat', '<label id="alamat-error" class="error invalid-feedback" for="alamat">:message</label>'); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label for="example-input-normal" class="form-label">Tahun Berdiri<span class="text-danger">*</span></label>
                                    <select name="tahun_berdiri" id="tahun_berdiri" class="form-control selectFormClass <?php echo e($errors->has('tahun_berdiri') ? 'is-invalid' : ''); ?>" required>
                                        <option value="">Tahun Berdiri</option>
                                        <?php for($i = 1900; $i < date('Y')+5; $i++): ?> 
                                            <option value="<?php echo e($i); ?>" <?php echo e(old('tahun_berdiri', $desa->desa->tahun_berdiri) == $i ? "selected" : ""); ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <?php echo $errors->first('tahun_berdiri', '<label id="tahun_berdiri-error" class="error invalid-feedback" for="tahun_berdiri">:message</label>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="nama" class="form-label">Pendamping Desa <span class="text-danger">*</span></label>
                                <input name="pendamping_desa" type="text" class="form-control <?php echo e($errors->has('pendamping_desa') ? 'is-invalid' : ''); ?>" id="pendamping_desa" value="<?php echo e(old('pendamping_desa', $desa->desa->pendamping_desa)); ?>" placeholder="Pendamping Desa" required>
                                <?php echo $errors->first('pendamping_desa', '<label id="pendamping_desa-error" class="error invalid-feedback" for="pendamping_desa">:message</label>'); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input name="email" type="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('email', $desa->desa->email)); ?>" placeholder="email@desa.com">
                                    <?php echo $errors->first('email', '<label id="email-error" class="error invalid-feedback" for="email">:message</label>'); ?>

                                </div>
                            </div>
                            <div class="col-6">
                                <div class="mb-3">
                                    <label for="telepon" class="form-label">Handphone</label>
                                    <input name="telepon" type="text" class="form-control <?php echo e($errors->has('telepon') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('telepon', $desa->desa->telepon)); ?>" placeholder="0812123456789">
                                    <?php echo $errors->first('telepon', '<label id="telepon-error" class="error invalid-feedback" for="telepon">:message</label>'); ?>

                                </div>
                            </div>
                        </div>
                        <div class="text-start">
                            <button type="submit" class="btn btn-success waves-effect waves-light mt-2" id="submitData"><i class="mdi mdi-content-save"></i> UPDATE</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/profile-vendor.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/profile/desa.blade.php ENDPATH**/ ?>