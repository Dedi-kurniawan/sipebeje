<form action="<?php echo e(route('admin.print-undangan')); ?>" method="GET">
    <input type="hidden" name="paket_id" value="<?php echo e($paket_id); ?>">
    <input type="hidden" name="vendor_id" value="<?php echo e($vendor_id); ?>">
    <input type="hidden" name="undangan_id" value="<?php echo e($undangan_id); ?>">
    <button class='btn btn-sm btn-outline-danger'><i class='fa fa-file-pdf'></i> Download</button>
</form><?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/backend/partials/action/print_undangan.blade.php ENDPATH**/ ?>