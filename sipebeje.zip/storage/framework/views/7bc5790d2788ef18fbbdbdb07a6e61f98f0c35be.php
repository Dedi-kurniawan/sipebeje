<?php $__env->startSection('title', 'LOGIN'); ?>

<?php $__env->startSection('content'); ?>
<div class="account-pages mt-5 mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-4">
                <div class="card bg-pattern">
                    <div class="card-body p-4">                                
                        <div class="text-center w-75 m-auto">
                            <div class="auth-logo">
                                <a href="#" class="logo logo-dark text-center">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('template/images/logo/logo-dark.png')); ?>" alt="" height="40">
                                    </span>
                                </a>                    
                                <a href="#" class="logo logo-light text-center">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('template/images/logo/logo-light.png')); ?>" alt="" height="40">
                                    </span>
                                </a>
                            </div>
                        </div> 
                        <form class="form" id="form_validate" method="POST" action="<?php echo e(route('frontend.login.post')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="emailaddress" class="form-label">Email</label>
                                <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>" id="email" required title="kolom email di larang kosong" placeholder="E-mail..." />
                                <?php echo $errors->first('email', '<label id="email-error" class="error invalid-feedback" for="email">:message</label>'); ?>

                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" placeholder="password..." required>
                                    <?php echo $errors->first('password', '<label id="password-error" class="error invalid-feedback" for="password">:message</label>'); ?>

                                    <div class="input-group-text" data-password="false">
                                        <span class="password-eye"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center d-grid">
                                <button class="btn btn-success" type="submit"> LOGIN </button>
                            </div>
                        </form>
                    </div> 
                </div>
            </div> 
        </div>
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/frontend/login/index.blade.php ENDPATH**/ ?>