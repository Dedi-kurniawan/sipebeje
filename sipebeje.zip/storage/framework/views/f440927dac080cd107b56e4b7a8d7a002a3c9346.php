
<?php $__env->startSection('title', $bread['first']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-lg-12">
            <div class="card d-block">
                <div class="card-body">
                    <h3 class="mt-0 font-20">
                        <?php echo e($show->nama_perusahaan); ?>

                    </h3>
                    <div class="badge bg-secondary text-light mb-3"><?php echo e($show->npwp); ?></div>
                    <h5>Deskripsi Usaha:</h5>
                    <p class="text-muted mb-2">
                        <?php echo e($show->deskripsi); ?>

                    </p>
                    <h5>Alamat:</h5>
                    <p class="text-muted mb-2">
                        <?php echo e($show->alamat); ?>

                    </p>
                    <p class="text-muted">Kecamatan : <?php echo e($show->kecamatan->nama); ?> <br> Desa : <?php echo e($show->desa->nama); ?></p>

                    <div class="mb-4">
                        <h5>Kontak</h5>
                        <div class="text-uppercase">
                            <a href="mailto:<?php echo e($show->email_perusahaan); ?>" class="btn btn-sm btn-soft-primary me-1"><i class="fa fa-envelope"></i> <?php echo e($show->email_perusahaan); ?></a>
                            <a href="tel:<?php echo e($show->telepon); ?>" class="btn btn-sm btn-soft-primary me-1"><i class="fa fa-phone"></i> <?php echo e($show->telepon); ?></a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-4">
                                <h5>E-mail Penanggung Jawab</h5>
                                <p><?php echo e($show->user->email); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/vendor/show.blade.php ENDPATH**/ ?>