
<?php $__env->startSection('title', $bread['first']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form id="form_validate" method="POST" action="<?php echo e(route('admin.profile.akun.post')); ?>">
                        <?php echo csrf_field(); ?>
                        <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i> UPDATE AKUN </h5>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="firstname" class="form-label">Nama <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e($akun->name); ?>" required>
                                    <?php echo $errors->first('name', '<label id="name-error" class="error invalid-feedback" for="name">:message</label>'); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e($akun->email); ?>" required>
                                    <?php echo $errors->first('email', '<label id="email-error" class="error invalid-feedback" for="email">:message</label>'); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" placeholder="**********">
                                    <?php echo $errors->first('password', '<label id="password-error" class="error invalid-feedback" for="password">:message</label>'); ?>

                                    <small class="text-danger">kosongkan password jika tidak ingin di ubah</small>
                                </div>
                            </div>
                        </div>
                        <div class="text-start">
                            <button type="submit" class="btn btn-success waves-effect waves-light mt-2"><i class="mdi mdi-content-save"></i> UPDATE</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/profile-vendor.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/profile/akun.blade.php ENDPATH**/ ?>