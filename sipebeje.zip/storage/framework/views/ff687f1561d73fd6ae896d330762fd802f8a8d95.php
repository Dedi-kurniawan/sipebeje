
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-titl text-uppercase"> FORMULIR <?php echo e($bread['second']); ?></h4>
                    <p class="mb-3"><?php echo e($edit->nama); ?></p>
                    <div id="rootwizard">
                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-3">
                            <?php echo $__env->make('backend.paket._tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                        <div class="tab-content mb-0 b-0 pt-0">
                            <div class="tab-pane <?php echo e($tab == "paket" ? "active" : ""); ?>" id="first">
                                <form id="form_validate" method="POST" action="<?php echo e(route('admin.paket.update', $edit->id)); ?>" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Nama Paket:<span class="text-danger">*</span></label>
                                                <textarea class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" name="nama" id="nama" cols="30" rows="3" title="kolom nama di larang kosong" placeholder="Paket..." required><?php echo e(old('nama', $edit->nama)); ?></textarea>
                                                <?php echo $errors->first('nama', '<label id="nama-error" class="error invalid-feedback" for="nama">:message</label>'); ?>

                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-6">
                                                    <label for="example-input-normal" class="form-label">Jenis:<span class="text-danger">*</span></label>
                                                    <select name="jenis" class="form-control selectFormClass <?php echo e($errors->has('jenis') ? 'is-invalid' : ''); ?>" id="jenis" required>
                                                        <option value="">Pilih Jenis</option>
                                                        <option value="Metode Penawaran" <?php echo e(old('jenis', $edit->jenis) == "Metode Penawaran" ? "selected" : ""); ?>>Metode Penawaran</option>
                                                        <option value="Metode Lelang" <?php echo e(old('jenis', $edit->jenis) == "Metode Lelang" ? "selected" : ""); ?>>Metode Lelang</option>
                                                    </select>
                                                    <?php echo $errors->first('jenis', '<label id="jenis-error" class="error invalid-feedback" for="jenis">:message</label>'); ?>

                                                </div>
                                                <div class="col-6">
                                                    <label for="example-input-normal" class="form-label">Penanggung Jawab:<span class="text-danger">*</span></label>
                                                    <select name="aparatur_id" class="form-control selectFormClass <?php echo e($errors->has('aparatur_id') ? 'is-invalid' : ''); ?>" id="aparatur_id" required title="Kolom penanggung jawab di larang kosong">
                                                        <option value="">Pilih Penanggung Jawab</option>
                                                        <?php $__currentLoopData = $aparatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($a->id); ?>" <?php echo e(old('aparatur_id', $edit->aparatur_id) == $a->id ? "selected" : ""); ?>><?php echo e($a->nama); ?>-<?php echo e($a->jabatan); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php echo $errors->first('aparatur_id', '<label id="aparatur_id-error" class="error invalid-feedback" for="aparatur_id">:message</label>'); ?>

                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">HPS:<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="btn input-group-text btn-dark waves-effect waves-light">Rp. </span>
                                                    <input type="text" class="form-control rupiah <?php echo e($errors->has('hps') ? 'is-invalid' : ''); ?>" autocomplete="off" name="hps" value="<?php echo e(old('hps', $edit->hps)); ?>" id="hps" title="kolom hps di larang kosong" placeholder="HPS..."/>
                                                    <?php echo $errors->first('hps', '<label id="hps-error" class="error invalid-feedback" for="hps">:message</label>'); ?>

                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">HPS (Terbilang):<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control <?php echo e($errors->has('terbilang') ? 'is-invalid' : ''); ?>" autocomplete="off" name="terbilang" value="<?php echo e(old('terbilang', $edit->terbilang)); ?>" id="terbilang" title="kolom terbilang di larang kosong" placeholder="HPS Terbilang..."/>
                                                    <button class="btn input-group-text btn-dark waves-effect waves-light" type="button" id="terbilang_rupiah"><i class="fas fa-sync-alt"></i></button>
                                                    <?php echo $errors->first('terbilang', '<label id="terbilang-error" class="error invalid-feedback" for="terbilang">:message</label>'); ?>

                                                </div>
                                                <small class="text-info">Perbaiki secara manual jika terjadi kesalahan</small>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Akhir Pendaftaran:<span class="text-danger">*</span></label>
                                                <input type="date" class="form-control <?php echo e($errors->has('tanggal_selesai') ? 'is-invalid' : ''); ?>" maxlength="100" autocomplete="off" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai', $edit->tanggal_selesai)); ?>" id="tanggal_selesai" title="kolom tanggal selesai di larang kosong" placeholder="Akhir Pendaftaran..." required />
                                                <?php echo $errors->first('tanggal_selesai', '<label id="tanggal_selesai-error" class="error invalid-feedback" for="tanggal_selesai">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Deskripsi:<span class="text-danger">*</span></label>
                                                <input type="hidden" name="keterangan" id="keterangan" value="<?php echo e(old('keterangan', $edit->keterangan)); ?>">
                                                <div id="editor" style="min-height: 160px;"><?php echo old('keterangan', $edit->keterangan); ?></div>
                                                <?php echo $errors->first('keterangan', '<label id="keterangan-error" class="error invalid-feedback" for="keterangan">:message</label>'); ?>

                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-12">
                                                    <input type="hidden" id="paket_id_value" value="<?php echo e($edit->id); ?>">
                                                    <button type="button" class="btn btn-success btn-md float-end" onclick="createData()">
                                                        <i class="fe-plus"></i> TAMBAH HPS
                                                    </button>
                                                </div>
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table id="datatable" class="table nowrap w-100 mt-3">
                                                            <thead>
                                                                <tr>
                                                                    <th>NO</th>
                                                                    <th>URAIAN</th>
                                                                    <th>VOLUME</th>
                                                                    <th>HARGA @</th>
                                                                    <th>SATUAN</th>
                                                                    <th>JUMLAH</th>
                                                                    <th>PAJAK</th>
                                                                    <th>HARGA SETELAH PAJAK</th>
                                                                    <th>KETERANGAN</th>
                                                                    <th>AKSI</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody></tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <button type="submit" class="btn btn-info width-md waves-effect waves-light">
                                                    <i class="fa fa-save"></i> SIMPAN
                                                </button>
                                                <a href="<?php echo e(route('admin.akk.edit', $edit->id)); ?>" class="btn btn-primary width-md waves-effect waves-light float-end">
                                                    KERANGKA ACUAN KERJA (KAK) <i class="fe-arrow-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('backend.paket._hps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('backend/libs/quill/quill.core.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/quill/quill.bubble.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/quill/quill.snow.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/quill/quill.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/pages/form-quilljs.init.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/mask/dist/jquery.mask.js')); ?>"></script>
<script src="<?php echo e(asset('template/barangjasa/admin/hps.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/paket/edit.blade.php ENDPATH**/ ?>