
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Menampilkan Data <?php echo e($bread['second']); ?></h4>
                    <p class="text-muted font-13 mb-4">
                        Total : <span id="total_data"></span> <?php echo e($bread['second']); ?></span>
                    </p>
                    <table id="dt_undangan" class="table dt-responsive w-100">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>DESA</th>
                                <th>NAMA PAKET</th>
                                <th>HPS</th>
                                <th>STATUS</th>
                                <th>AKHIR PENDAFTARAN</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/undangan-vendor.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/undangan/index.blade.php ENDPATH**/ ?>