<option value="">Pilih <?php echo e($title); ?></option>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($d->id); ?>" <?php echo e($d->id == $selected ? "selected" : ""); ?>><?php echo e($d->nama_perusahaan); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/layouts/backend/partials/select.blade.php ENDPATH**/ ?>