
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="header-title text-uppercase"> FORMULIR <?php echo e($bread['second']); ?></h4>
                    <p class="mb-3"><?php echo e($edit->nama); ?></p>

                    <div id="rootwizard">
                        <ul class="nav nav-pills bg-light nav-justified form-wizard-header mb-3">
                            <?php echo $__env->make('backend.paket._tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>

                        <div class="tab-content mb-0 b-0 pt-0">
                            <div class="tab-pane <?php echo e($tab == "undangan" ? "active" : ""); ?>" id="first">
                                <form id="form_validate" method="POST" action="<?php echo e(route('admin.undangan.update', $edit->id)); ?>" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Nomor Undangan<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('nomor') ? 'is-invalid' : ''); ?>" maxlength="255" autocomplete="off" name="nomor" id="nomor" value="<?php echo e(old('nomor', $edit->undangan->nomor)); ?>" title="kolom nomor di larang kosong" placeholder="Nomor..."required />
                                                <?php echo $errors->first('nomor', '<label id="nomor-error"class="error invalid-feedback" for="nomor">:message</label>'); ?>

                                            </div>
                                            <div class="mb-3">
                                                <label for="example-input-normal" class="form-label">Perihal<span class="text-danger">*</span></label>
                                                <input type="text"class="form-control <?php echo e($errors->has('perihal') ? 'is-invalid' : ''); ?>"maxlength="255" autocomplete="off" name="perihal" disabled id="perihal" value="<?php echo e(old('perihal', $edit->undangan->perihal) == NULL ? $edit->nama : $edit->undangan->perihal); ?>" title="kolom perihal di larang kosong" placeholder="Perihal..." required />
                                                <?php echo $errors->first('perihal', '<label id="perihal-error"class="error invalid-feedback" for="perihal">:message</label>'); ?>

                                            </div>
                                            <div class="mb-2">
                                                <label for="example-input-normal" class="form-label">Pilih Vendor YangAkan Di Undang<span class="text-danger">*</span></label>
                                            </div>
                                            <div class="mb-1">
                                                <div class="row">
                                                    
                                                    <div class="col-10">
                                                        <input type="hidden" id="undangan_id" value="<?php echo e($edit->undangan->id); ?>">
                                                        <input type="hidden" id="paket_id" value="<?php echo e($edit->id); ?>">
                                                        <input type="hidden" id="user_desa_id" value="<?php echo e(Auth::user()->desa_id); ?>">
                                                        <label for="example-input-normal" class="form-label">Vendor<span class="text-danger">*</span></label>
                                                        <select class="form-control selectFormClass" id="vendor_id" name="vendor_id"></select>
                                                        <label id='vendor_id_error' class='error text-danger' for='vendor_id_error'></label>
                                                    </div>
                                                    <div class="col-2">
                                                        <label for="">Aksi</label>
                                                        <div></div>
                                                        <span id="addVendor" class="btn btn-primary mt-2">Tambah</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="table-responsive">
                                                <h5><span id="total_data_vendor"></span> total penyedia</h5>
                                                <table id="dt_vendor" class="table table-bordered table-sm nowrap w-100 text-center">
                                                    <thead>
                                                        <tr>
                                                            <th>NO</th>
                                                            <th>DESA</th>
                                                            <th>PERUSAHAAN</th>
                                                            <th>STATUS</th>
                                                            <th>AKSI</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                            </div>
                                            <br>
                                            <div class="mb-2">
                                                <label for="example-input-normal" class="form-label">1. Paket Pengadaan Material/Jasa<span class="text-danger">*</span></label>
                                            </div>
                                            
                                            <div class="table-responsive">
                                                <table id="dt_material" class="table table-bordered nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                            <th>NO</th>
                                                            <th>URAIAN</th>
                                                            <th>VOLUME</th>
                                                            <th>SATUAN</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    </tbody>
                                                </table>
                                            </div>
                                            
                                            <div class="mb-3 mt-2">
                                                <label for="example-input-normal" class="form-label">Sumber dana (APB Desa Tahun Anggaran)<span class="text-danger">*</span></label>
                                                <div class="mb-3">
                                                    <label for="example-input-normal" class="form-label">Perihal<span class="text-danger">*</span></label>
                                                    <input type="text"class="form-control <?php echo e($errors->has('sumber_dana') ? 'is-invalid' : ''); ?>"maxlength="255" autocomplete="off" name="sumber_dana" id="sumber_dana" disabled value="<?php echo e(date('Y')); ?>" placeholder="Perihal..."required />
                                                    <?php echo $errors->first('perihal', '<label id="perihal-error"class="error invalid-feedback" for="perihal">:message</label>'); ?>

                                                </div>
                                                <?php echo $errors->first('sumber_dana', '<label id="sumber_dana-error" class="error invalid-feedback" for="sumber_dana">:message</label>'); ?>

                                            </div>
                                            <hr>
                                            <div class="text-sm-end">
                                                <a href="<?php echo e(route('admin.hps.edit', $edit->id)); ?>" class="btn btn-primary width-md waves-effect waves-light float-start">
                                                    <i class="fe-arrow-left"></i> HARGA PERKIRAAN KERJA (HPS)
                                                </a>
                                                <button type="submit" data-toggle="tooltip" title="Undangan akan di kirim secara otomatis ke semua vendor" tabindex="0" data-plugin="tippy" data-tippy-arrow="true" data-tippy-arrowTransform="scaleX(1.5)" data-tippy-animation="fade" class="btn btn-info width-md waves-effect waves-light submitForm" name="submit" data-name="Otomatis" value="otomatis"> KIRIM UNDANGAN <i class="fab fa-telegram-plane"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('backend.paket._material', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/js/mask/dist/jquery.mask.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/tippy.js/tippy.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/barangjasa/admin/undangan.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/paket/undangan.blade.php ENDPATH**/ ?>