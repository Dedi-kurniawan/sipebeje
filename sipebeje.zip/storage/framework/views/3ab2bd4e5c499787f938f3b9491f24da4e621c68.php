
<?php $__env->startSection('title', $bread['third']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Detail <?php echo e($bread['second']); ?></h4>
                    <table class="table table-bordered table-sm w-100">
                        <tbody>
                            <tr>
                                <td class="text-capitalize">Nama Paket</td>
                                <td><?php echo e($show->nama); ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">HPS</td>
                                <td class="fw-bold">Rp. <?php echo e(number_format($show->hps,2,',','.')); ?> (<?php echo e($show->terbilang); ?>)</td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Jenis</td>
                                <td><?php echo e($show->jenis); ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Akhir Pendaftaran</td>
                                <td><?php echo $show->TanggalSelesaiAt; ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Status</td>
                                <td><?php echo $show->StatusFormatAt; ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Kecamatan</td>
                                <td><?php echo e($show->desa->kecamatan->nama); ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Desa</td>
                                <td><?php echo e($show->desa->nama); ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Penannggung Jawab</td>
                                <td><?php echo e($show->aparatur->nama); ?> - <?php echo e($show->aparatur->jabatan); ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Pemenang</td>
                                <td><?php echo e($show->vendor_id == NULL ? "-" : $show->vendor->nama_perusahaan); ?></td>
                            </tr>
                            <tr>
                                <td class="text-capitalize">Deskripsi</td>
                                <td><?php echo $show->keterangan; ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="w-100">
                        <thead class="text-center justify-content-center">
                            <tr>
                                <td colspan="2" class="fw-bold">KERANGKA ACUAN KERJA (KAK)</td>
                            </tr>
                            <tr>
                                <td class="text-uppercase fw-bold" colspan="2">KEGIATAN <?php echo e($show->akk->kegiatan); ?></td>
                            </tr>
                            <tr>
                                <td class="text-uppercase fw-bold" colspan="2">DUSUN <?php echo e($show->akk->dusun); ?> RT <?php echo e($show->akk->rt); ?></td>
                            </tr>
                        </thead>
                    <table>
                    <table class="table table-bordered table-sm w-100">
                        <tbody>
                            <tr>
                                <td class="fw-bold text-nowrap">I. LATAR BELAKANG</td>
                                <td><?php echo $show->akk->latar_belakang; ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">II.	MAKSUD DAN TUJUAN</td>
                                <td>
                                    Maksud : <br> <?php echo $show->akk->maksud; ?>

                                    <br>
                                    Tujuan : <br> <?php echo $show->akk->tujuan; ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">III. HASIL YANG DIHARAPKAN</td>
                                <td>
                                    <?php echo $show->akk->hasil; ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">IV.	LOKASI KEGIATAN</td>
                                <td>
                                    <?php echo $show->akk->lokasi_kegiatan; ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">V. DASAR PENGANGGARAN</td>
                                <td class="text-uppercase">
                                    <?php echo $show->akk->dasar_penganggaran; ?> NO <?php echo e($show->akk->dp_no); ?> TGL <?php echo e($show->akk->dp_tgl); ?> BIDANG <?php echo e($show->akk->dp_bidang); ?> SUBBIDANG <?php echo e($show->akk->dp_subbidang); ?> KEGIATAN <?php echo e($show->akk->dp_kegiatan); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">VI.	JANGKA WAKTU PELAKSANAAN</td>
                                <td>
                                    <?php echo $show->akk->waktu_pelaksanaan; ?> HARI
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">VII. GAMBARAN PELAKSANAAN KEGIATAN</td>
                                <td>
                                    <?php echo $show->akk->gambaran_pelaksanaan; ?> 
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">VIII. SPESIFIKASI TEKNIS (TERLAMPIR)</td>
                                <td>
                                    <?php echo $show->akk->spesifikasi_teknis; ?> 
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">IX.	DAFTAR TENAGA KERJA DARI DESA</td>
                                <td>
                                    <?php echo $show->akk->tenaga_kerja; ?> 
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">X. METODE PENGADAAN</td>
                                <td>
                                    <?php echo $show->akk->metode_pengadaan; ?> 
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold text-nowrap">XI.	PAGU ANGGARAN</td>
                                <td>
                                    Rp. <?php echo e(number_format($show->akk->pagu_anggaran_rp,2,',','.')); ?> (<?php echo e($show->akk->pagu_anggaran_terbilang); ?>)
                                </td>
                            </tr>
                        </tbody>
                    </table> 
                    <table class="w-100">
                        <thead class="text-center justify-content-center">
                            <tr>
                                <td colspan="2" class="fw-bold">HARGA PERKIRAAN KERJA (HPS)</td>
                            </tr>
                        </thead>
                    </table> 
                    <table class="table table-bordered table-sm w-100">
                        <thead>
                            <tr>
                                <th>URAIAN</th>
                                <th>VOLUME</th>
                                <th>HARGA @</th>
                                <th>SATUAN</th>
                                <th>JUMLAH</th>
                                <th>PAJAK</th>
                                <th>HARGA SETELAH PAJAK</th>
                                <th>KETERANGAN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $show->hpsTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($hps->uraian); ?></td>
                                    <td><?php echo e($hps->volume); ?></td>
                                    <td><?php echo e(number_format($hps->harga_satuan,2,',','.')); ?></td>
                                    <td><?php echo e($hps->satuan); ?></td>
                                    <td><?php echo e(number_format($hps->jumlah,2,',','.')); ?></td>
                                    <td><?php echo e($hps->pajak); ?> %</td>
                                    <td><?php echo e(number_format($hps->jumlah + $hps->harga_pajak,2,',','.')); ?></td>
                                    <td><?php echo e($hps->keterangan); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <table class="w-100">
                        <thead class="text-center justify-content-center">
                            <tr>
                                <td colspan="2" class="fw-bold">VENDOR DI UNDANGAN</td>
                            </tr>
                        </thead>
                    </table> 
                    <table class="table table-bordered table-sm w-100">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>DESA</th>
                                <th>PERUSAHAAN</th>
                                <th>STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $show->undanganVendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($u->vendor->desa->nama); ?></td>
                                    <td><?php echo e($u->vendor->nama_perusahaan); ?></td>
                                    <td>
                                        <?php if($u->status == "2"): ?>
                                            <span class='badge bg-sm bg-success'>Ikut</span>
                                        <?php elseif($u->status == "1"): ?> 
                                            <span class='badge bg-sm bg-danger'>Tidak Ikut</span>
                                        <?php else: ?>
                                            <span class='badge bg-sm bg-info'>Belum di Konfirmasi</span>
                                        <?php endif; ?>  
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <hr>
                    <div class="mb-3">
                        <a href="<?php echo e(route('admin.paket.index')); ?>" class="btn btn-primary width-md waves-effect waves-light float-start">
                            <i class="fe-arrow-left"></i> KEMBALI 
                         </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/paket/show.blade.php ENDPATH**/ ?>