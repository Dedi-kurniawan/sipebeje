<li class="dropdown notification-list topbar-dropdown">
              <a class="nav-link dropdown-toggle waves-effect waves-light" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                  <i class="fe-bell noti-icon"></i>
                  <span class="badge bg-danger rounded-circle noti-icon-badge"><?php echo e($countnotifikasi); ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-lg">
                  <div class="dropdown-item noti-title">
                      <h5 class="m-0">
                          <span class="float-end">
                          </span>Notification
                      </h5>
                  </div>
  
                  <div class="noti-scroll" data-simplebar>
                    <?php $__empty_1 = true; $__currentLoopData = $user->unreadNotifications->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('admin.read.notif', $notification->id)); ?>" class="dropdown-item notify-item">
                            <div class="notify-icon bg-primary">
                                <i class="mdi mdi-comment-account-outline"></i>
                            </div>
                            <p class="notify-details"><?php echo e($notification->data['notif']); ?>

                                <small class="text-muted"><?php echo e($notification->data['date']); ?></small>
                            </p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="d-flex flex-column font-weight-bold">
                            <span class="text-center">TIDAK ADA NOTIFIKASI</span>
                        </div>
                    <?php endif; ?>
                  </div>
  
                  <!-- All-->
                  
  
              </div>
            </li><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/layouts/backend/partials/notifikasi.blade.php ENDPATH**/ ?>