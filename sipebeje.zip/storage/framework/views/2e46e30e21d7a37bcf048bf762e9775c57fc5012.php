<div class="left-side-menu">

  <div class="h-100" data-simplebar>
      <div id="sidebar-menu">
          <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'kabupaten'): ?>
            <?php echo $__env->make('layouts.backend.partials.menu.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php elseif(Auth::user()->role == 'desa'): ?>
            <?php echo $__env->make('layouts.backend.partials.menu.desa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php elseif(Auth::user()->role == 'vendor'): ?>
            <?php echo $__env->make('layouts.backend.partials.menu.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endif; ?>
      </div>
      <div class="clearfix"></div>
  </div>
</div><?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/backend/partials/sidebar.blade.php ENDPATH**/ ?>