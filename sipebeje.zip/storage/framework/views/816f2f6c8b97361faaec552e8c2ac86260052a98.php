
<?php $__env->startSection('title', $bread['first']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form id="form_validate" method="POST" action="<?php echo e(route('admin.ba-pekerjaan.update', $edit->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <h5 class="mb-4 text-uppercase">
                            <i class="mdi mdi-mail me-1"></i> FORMULIR BERITA ACARA SERAH TERIMA PEKRJAAN
                        </h5>
                        <div class="col-12 mb-2">
                            <label for="example-input-normal" class="form-label">Nomor:<span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php echo e($errors->has('nomor_surat') ? 'is-invalid' : ''); ?>" autocomplete="off" readonly name="nomor_surat" value="<?php echo e(old('nomor_surat', $edit->nomor_surat)); ?>"  id="nomor_surat" title="kolom nomor surat di larang kosong" placeholder="nomor surat..." required/>
                            <?php echo $errors->first('nomor_surat', '<label id="nomor_surat-error" class="error invalid-feedback" for="nomor_surat">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">Tanggal:<span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" autocomplete="off" readonly name="tanggal" value="<?php echo e(old('tanggal', $edit->tanggal)); ?>"  id="tanggal" title="kolom tanggal selesai di larang kosong" placeholder="Akhir Pendaftaran..." required/>
                            <?php echo $errors->first('tanggal', '<label id="tanggal-error" class="error invalid-feedback" for="tanggal">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">Paket:<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" value="<?php echo e($edit->paket->nama); ?>"  readonly/>
                        </div>
                        <div class="row mb-3">
                            <div class="col-12 mb-2">
                                <table class="table dt-responsive w-100">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>Uraian Barang</th>
                                            <th>Volume</th>
                                            <th>CheckList</th>
                                            <th>Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key + 1); ?></td>
                                                <td><?php echo e($x->uraian); ?></td>
                                                <td><?php echo e($x->volume); ?> <?php echo e($x->satuan); ?></td>
                                                <td>
                                                    <div class="form-check mb-2">
                                                        <input class="form-check-input" type="radio" name="details[<?php echo e($x->id); ?>][checklist]" value="Ada" id="radio1<?php echo e($x->id); ?>" <?php echo e($x->checklist == 'Ada' ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="radio1<?php echo e($x->id); ?>">Ada</label>
                                                    </div>
                                                    <div class="form-check mb-2">
                                                        <input class="form-check-input" type="radio" name="details[<?php echo e($x->id); ?>][checklist]" value="Tidak Ada" id="radio2<?php echo e($x->id); ?>" <?php echo e($x->checklist == 'Tidak Ada' ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="radio2<?php echo e($x->id); ?>">Tidak Ada</label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <textarea name="details[<?php echo e($x->id); ?>][keterangan]" class="form-control" id="keterangan_<?php echo e($x->id); ?>" cols="30" rows="3"><?php echo e($x->checklist_keterangan); ?></textarea>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/ba-pekerjaan-detail.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/BaPekerjaan/detail.blade.php ENDPATH**/ ?>