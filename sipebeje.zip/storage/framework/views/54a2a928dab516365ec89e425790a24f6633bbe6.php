<footer class="footer">
  <div class="container-fluid">
      <div class="row">
          <div class="col-md-6">
              <script>document.write(new Date().getFullYear())</script> &copy; Dinas Pemberdayaan Masyarakat dan Desa <a href="">Bengkulu utara</a> 
          </div>
           <div class="col-md-6">
              <div class="text-md-end footer-links d-none d-sm-block">
                  <a href="javascript:void(0);">Aplikasi SIPEBEJE Vesi 1.0</a>
              </div>
          </div> 
      </div>
  </div>
</footer><?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/backend/partials/footer.blade.php ENDPATH**/ ?>