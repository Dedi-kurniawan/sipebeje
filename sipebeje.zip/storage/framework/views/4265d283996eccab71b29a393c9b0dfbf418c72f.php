
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title">LAPORAN PENGADAAN BARANG JASA PER DESA</h4>
                </div>
                <div class="card-body">
                    <form id="form_validate" method="GET" action="<?php echo e(route('admin.laporan.cetak')); ?>">
                        <?php echo method_field('GET'); ?>
                        <div class="row">
                            <div class="mb-3 col-3">
                                <label for="example-input-normal" class="form-label">Dari:<span class="text-danger">*</span></label>
                                <input type="date" class="form-control" autocomplete="off" name="dari" value="<?php echo e(old('dari')); ?>"  id="dari" title="kolom dari di larang kosong" placeholder="Dari..." required/>
                            </div>
                            <div class="mb-3 col-3">
                                <label for="example-input-normal" class="form-label">Sampai:<span class="text-danger">*</span></label>
                                <input type="date" class="form-control" autocomplete="off" name="sampai" value="<?php echo e(old('sampai')); ?>"  id="sampai" title="kolom sampai di larang kosong" placeholder="Sampai..." required/>
                            </div>
                            <div class="mb-3 col-3">
                                <label for="example-input-normal" class="form-label">Desa</label>
                                <select name="desa" class="form-control selectFormClass" id="desa">
                                    <option value="">Semua Desa</option>
                                    <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($x->id); ?>"><?php echo e($x->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3 col-3">
                                <label for="example-input-normal" class="form-label">&nbsp;</label> <br>
                                <button type="submit" class="btn btn-blue waves-effect waves-light">
                                    <i class="mdi mdi-download"></i> Download
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title">LAPORAN DAFTAR PENYEDIA YANG DI TERDAFTAR DI SIPEBEJE</h4>
                </div>
                <div class="card-body">
                    <form id="form_validate" method="GET" action="<?php echo e(route('admin.laporan.penyedia')); ?>">
                        <?php echo method_field('GET'); ?>
                        <div class="row">
                            <div class="mb-3 col-3">
                                <label for="example-input-normal" class="form-label">Desa</label>
                                <select name="desa" class="form-control selectFormClass" id="desa">
                                    <option value="">Semua Desa</option>
                                    <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($x->id); ?>"><?php echo e($x->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3 col-3">
                                <label for="example-input-normal" class="form-label">&nbsp;</label> <br>
                                <button type="submit" class="btn btn-blue waves-effect waves-light">
                                    <i class="mdi mdi-download"></i> Download
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/laporan/index.blade.php ENDPATH**/ ?>