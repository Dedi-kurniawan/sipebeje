
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title text-uppercase"><?php echo e($bread['third']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="w-100">
                        <thead class="text-center justify-content-center">
                            <tr>
                                <td colspan="2" class="fw-bold">TIM PENGELOLA KEGIATAN</td>
                            </tr>
                            <tr>
                                <td class="text-uppercase fw-bold" colspan="2">DESA <?php echo e($show->desa->nama); ?> KECAMATAN <?php echo e($show->desa->kecamatan->nama); ?></td>
                            </tr>
                            <tr>
                                <td><hr></td>
                            </tr>
                        </thead>
                    <table>                            
                    <table class="w-100">
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td class="float-end"><?php echo e($show->undangan->CreatedAtFormat); ?></td>
                            </tr>
                            <tr>
                                <td>Nomor</td>
                                <td>:</td>
                                <td><?php echo e($show->undangan->nomor); ?></td>
                            </tr>
                            <tr>
                                <td>Lampiran</td>
                                <td>:</td>
                                <td>1 (satu) dokumen)</td>
                            </tr>
                            <tr>
                                <td>Kepada Yth.</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Pimpinan Penyedia <?php echo e($undangan->vendor->nama_perusahaan); ?></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Di <?php echo e($undangan->vendor->alamat); ?></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Perihal</td>
                                <td>:</td>
                                <td><?php echo e($show->undangan->perihal); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="text-left">
                        1.	Paket Pengadaan Material/Jasa Uraian material	
                    </div>
                    <div class="table-responsive">                                                
                        <table id="dt_material" class="table table-bordered nowrap w-100">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>URAIAN</th>
                                    <th>VOLUME</th>
                                    
                                    <th>SATUAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $show->hpsTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($m->uraian); ?></td>
                                        <td><?php echo e($m->volume); ?></td>
                                        
                                        <td><?php echo e($m->satuan); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <table>
                            <tbody>
                                <tr>
                                    <td>Niai total</td>
                                    <td>:</td>
                                    <td class="float-end"><?php echo e(number_format($show->hps,2,',','.')); ?> (<?php echo e($show->terbilang); ?>)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-left">
                        2.	Pelaksanaan Pengadaan
                    </div>           
                        <table class="w-100">
                        <tbody>
                            <tr>
                                <td>Tempat dan alamat</td>
                                <td>:</td>
                                <td>Kantor Desa <?php echo e($show->desa->nama); ?>  <?php echo e($show->desa->alamat); ?> </td>
                            </tr>
                        </tbody>
                    </table>     
                    <div class="">
                        Saudara diminta untuk memasukkan penawaran, teknis dan harga secara langsung sesuai dengan jadwal pelaksanaan sebagai berikut:
                    </div>              
                    <div class="table-responsive">                                                
                        <table id="dt_material" class="table table-bordered nowrap w-100">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>URAIAN</th>
                                    <th>VOLUME</th>
                                    <th>HARGA @</th>
                                    <th>SATUAN</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>   
                            </tbody>
                        </table>
                    </div>      
                    <div class="mt-2">
                        Apabila Saudara memerlukan keterangan dan penjelasan lebih lanjut, dapat menghubungi Tim Pengelola Kegiatan (TPK) Desa <?php echo e($show->desa->nama); ?>. sesuai alamat tersebut diatas sampai dengan batas akhir pemasukan Dokumen Penawaran.
                        <br>Demikian disampaikan untuk diketahui.
                    </div>   
                    <div class="float-end">
                        Untuk dan atas nama TPK Ketua, <br>
                       <span class="text-center"> <?php echo e($show->aparatur->nama); ?> </span>
                    </div>
                    <div class="mt-5 text-small">
                        Akhir Pendaftaran, <br>
                       <span class="text-center"> <?php echo $show->TanggalSelesaiAt; ?> </span>
                    </div>
                    <hr>
                    <form action="<?php echo e(route('admin.undangan.paket.konfirmasi.post', $show->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mt-3">
                            <input type="hidden" name="paket_id" value="<?php echo e($show->id); ?>">
                            <input type="hidden" name="undangan_id" value="<?php echo e($undangan->undangan_id); ?>">
                            <input type="hidden" name="vendor_id" value="<?php echo e($undangan->vendor_id); ?>">
                            <button name="submit" value="2" class="btn btn-success width-md waves-effect waves-light float-start">
                                <i class="fe-arrow-left"></i> IKUT PENAWARAN 
                            </button>
                            <button name="submit" value="1" class="btn btn-danger width-md waves-effect waves-light float-end">
                                <i class="fe-arrow-left"></i> TOLAK PENAWARAN 
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/undangan/undangan.blade.php ENDPATH**/ ?>