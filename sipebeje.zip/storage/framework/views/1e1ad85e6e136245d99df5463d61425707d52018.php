<li class="nav-item" data-target-form="#accountForm">
    <a href="<?php echo e(route('admin.paket.edit', $edit->id)); ?>" class="nav-link rounded-0 pt-2 pb-2 <?php echo e($tab == "paket" ? "active" : ""); ?>">
        <i class="mdi mdi-file me-1"></i>
        <span class="d-none d-sm-inline">PAKET</span>
    </a>
</li>
<li class="nav-item" data-target-form="#profileForm">
    <a href="<?php echo e(route('admin.akk.edit', $edit->id)); ?>" class="nav-link rounded-0 pt-2 pb-2 <?php echo e($tab == "akk" ? "active" : ""); ?>">
        <i class="mdi mdi-file-sync me-1"></i>
        <span class="d-none d-sm-inline">KERANGKA ACUAN KERJA (KAK)</span>
        <i class="mdi <?php echo e($edit->akk_field == "0" ? "mdi-close-thick text-danger" : "mdi-check-bold text-success"); ?>"></i>
    </a>
</li>

<li class="nav-item" data-target-form="#otherForm">
    <a href="<?php echo e(route('admin.undangan.edit', $edit->id)); ?>" class="nav-link rounded-0 pt-2 pb-2 <?php echo e($tab == "undangan" ? "active" : ""); ?>">
        <i class="mdi mdi-checkbox-marked-circle-outline me-1"></i>
        <span class="d-none d-sm-inline text-uppercase">UNDANGAN</span>
        <i class="mdi <?php echo e($edit->undangan_field == "0" ? "mdi-close-thick text-danger" : "mdi-check-bold text-success"); ?>"></i>
    </a>
</li><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/paket/_tab.blade.php ENDPATH**/ ?>