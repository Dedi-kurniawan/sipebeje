<?php if(Session::get('status')): ?>
<script>
    var action = "<?php echo e(Session::get('action')); ?>";
    var title = "<?php echo e(Session::get('title')); ?>";
    var message = "<?php echo e(Session::get('message')); ?>";
    notifToast(action, title, message);
</script>
<?php endif; ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/frontend/partials/notif.blade.php ENDPATH**/ ?>