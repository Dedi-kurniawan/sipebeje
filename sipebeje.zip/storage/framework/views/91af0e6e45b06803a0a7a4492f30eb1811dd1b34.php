<?php if($role == "admin" || $role == "kabupaten"): ?>
    <a href="<?php echo e($edit); ?>" class="btn btn-sm btn-outline-success">
        <i class="fa fa-pen"></i> Ubah
    </a>
    <button id="deleteData" data-id="<?php echo e($id); ?>" data-name="<?php echo e($name); ?>" class="btn btn-sm btn-outline-danger">
        <i class="fa fa-trash"></i> Hapus
    </button>
    <a href="<?php echo e($show); ?>" class="btn btn-sm btn-outline-info">
        <i class="fa fa-pen"></i> Detail
    </a>
<?php else: ?>
    <a href="<?php echo e($show); ?>" class="btn btn-sm btn-outline-info">
        <i class="fa fa-list"></i> Detail
    </a>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/backend/partials/action/vendor.blade.php ENDPATH**/ ?>