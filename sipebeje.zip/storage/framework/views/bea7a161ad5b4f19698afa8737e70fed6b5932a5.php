
<?php $__env->startSection('title', $bread['first']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form id="form_validate" method="POST" action="<?php echo e(route('admin.surat-pesanan.update', $edit->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <h5 class="mb-4 text-uppercase"><i class="mdi mdi-mail me-1"></i> FORMULIR SURAT PESANAN BARU </h5>
                        <div class="row">
                            <div class="col-12 mb-2">
                                <label for="example-input-normal" class="form-label">Nomor:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php echo e($errors->has('nomor_surat') ? 'is-invalid' : ''); ?>" autocomplete="off" name="nomor_surat" value="<?php echo e(old('nomor_surat', $edit->nomor_surat)); ?>"  id="nomor_surat" title="kolom nomor surat di larang kosong" placeholder="nomor surat..." required/>
                                <?php echo $errors->first('nomor_surat', '<label id="nomor_surat-error" class="error invalid-feedback" for="nomor_surat">:message</label>'); ?>

                            </div>
                            <div class="col-12 mb-2">
                                <label for="example-input-normal" class="form-label">Ketua TPK:<span class="text-danger">*</span></label>
                                <select name="aparatur_id" class="form-control selectForm <?php echo e($errors->has('aparatur_id') ? 'is-invalid' : ''); ?>" id="aparatur_id" required title="Kolom ketua tpk di larang kosong">
                                    <option value="">Pilih Ketua TPK</option>
                                    <?php $__currentLoopData = $aparatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a->id); ?>" <?php echo e(old('aparatur_id', $edit->aparatur_id) == $a->id ? "selected" : ""); ?>><?php echo e($a->nama); ?> - <?php echo e($a->jabatan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php echo $errors->first('aparatur_id', '<label id="aparatur_id-error" class="error invalid-feedback" for="aparatur_id">:message</label>'); ?>

                            </div>
                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">Alamat Ketua TPK:<span class="text-danger">*</span></label>
                            <textarea name="alamat_aparatur" id="alamat_aparatur" class="form-control <?php echo e($errors->has('alamat_aparatur') ? 'is-invalid' : ''); ?>" cols="3" rows="3" title="Kolom alamat ketua tpk di larang kosong" required><?php echo e(old('alamat_aparatur', $edit->alamat_aparatur)); ?></textarea>
                            <?php echo $errors->first('alamat_aparatur', '<label id="alamat_aparatur-error" class="error invalid-feedback" for="alamat_aparatur">:message</label>'); ?>

                        </div>
                        <div class="col-12 mb-2">
                            <label for="example-input-normal" class="form-label">Penyedia:<span class="text-danger">*</span></label>
                            <select name="vendor_id" class="form-control selectForm <?php echo e($errors->has('vendor_id') ? 'is-invalid' : ''); ?>" id="vendor_id" required title="Kolom penyedia di larang kosong">
                                <option value="">Pilih Penyedia</option>
                                <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a->id); ?>" <?php echo e(old('vendor_id', $edit->vendor_id) == $a->id ? "selected" : ""); ?>><?php echo e($a->nama_perusahaan); ?> - <?php echo e($a->name_vendor); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('vendor_id', '<label id="vendor_id-error" class="error invalid-feedback" for="vendor_id">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">Tanggal:<span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php echo e($errors->has('tanggal') ? 'is-invalid' : ''); ?>" autocomplete="off" name="tanggal" value="<?php echo e(old('tanggal', $edit->tanggal)); ?>"  id="tanggal" title="kolom tanggal selesai di larang kosong" placeholder="Akhir Pendaftaran..." required/>
                            <?php echo $errors->first('tanggal', '<label id="tanggal-error" class="error invalid-feedback" for="tanggal">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">Tanggal barang diterima paling lambat:<span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php echo e($errors->has('tanggal_lambat') ? 'is-invalid' : ''); ?>" autocomplete="off" name="tanggal_lambat" value="<?php echo e(old('tanggal_lambat', $edit->tanggal_lambat)); ?>"  id="tanggal_lambat" title="kolom tanggal lambat selesai di larang kosong" placeholder="Akhir Pendaftaran..." required/>
                            <?php echo $errors->first('tanggal_lambat', '<label id="tanggal_lambat-error" class="error invalid-feedback" for="tanggal_lambat">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label"> Dibebankan Kepada:<span class="text-danger">*</span></label>
                            <textarea name="beban_kepada" id="beban_kepada" class="form-control <?php echo e($errors->has('beban_kepada') ? 'is-invalid' : ''); ?>" cols="3" rows="3" title="Kolom beban kepada di larang kosong" required><?php echo e(old('beban_kepada', $edit->beban_kepada)); ?></textarea>
                            <?php echo $errors->first('beban_kepada', '<label id="beban_kepada-error" class="error invalid-feedback" for="beban_kepada">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">Jenis Belanja:<span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php echo e($errors->has('jenis_belanja') ? 'is-invalid' : ''); ?>" autocomplete="off" name="jenis_belanja" value="<?php echo e(old('jenis_belanja', $edit->jenis_belanja)); ?>"  id="jenis_belanja" title="kolom jenis belanja selesai di larang kosong" placeholder="Jenis Belanja..." required/>
                            <?php echo $errors->first('jenis_belanja', '<label id="jenis_belanja-error" class="error invalid-feedback" for="jenis_belanja">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label"> Uraian rincian Jenis Belanja:<span class="text-danger">*</span></label>
                            <textarea name="uraian_jenis_belanja" id="uraian_jenis_belanja" class="form-control <?php echo e($errors->has('uraian_jenis_belanja') ? 'is-invalid' : ''); ?>" cols="3" rows="3" title="Kolom uraian rincian jenis belanja di larang kosong" required><?php echo e(old('uraian_jenis_belanja', $edit->uraian_jenis_belanja)); ?></textarea>
                            <?php echo $errors->first('uraian_jenis_belanja', '<label id="uraian_jenis_belanja-error" class="error invalid-feedback" for="uraian_jenis_belanja">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">PPN:<span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php echo e($errors->has('ppn') ? 'is-invalid' : ''); ?>" autocomplete="off" name="ppn" value="<?php echo e(old('ppn', $edit->ppn)); ?>"  id="ppn" title="kolom ppn selesai di larang kosong" placeholder="PPN..." required/>
                            <?php echo $errors->first('ppn', '<label id="ppn-error" class="error invalid-feedback" for="ppn">:message</label>'); ?>

                        </div>
                        <div class="mb-2">
                            <label for="example-input-normal" class="form-label">PPH:<span class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php echo e($errors->has('pph') ? 'is-invalid' : ''); ?>" autocomplete="off" name="pph" value="<?php echo e(old('pph', $edit->pph)); ?>"  id="pph" title="kolom pph selesai di larang kosong" placeholder="pph..." required/>
                            <?php echo $errors->first('pph', '<label id="pph-error" class="error invalid-feedback" for="pph">:message</label>'); ?>

                        </div>
                        <div class="row mb-3">
                            <div class="col-12 mb-2">
                                <button type="button" class="btn btn-sm btn-blue waves-effect waves-light float-start" id="createData">
                                    <i class="mdi mdi-plus-circle"></i> Tambah Rincian
                                </button>
                            </div>
                            <div class="col-12 mb-2">
                                <table id="datatable" class="table dt-responsive w-100">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>Uraian Barang</th>
                                            <th>Volume</th>
                                            <th>Satuan</th>
                                            <th>SP</th>
                                            <th>Total  Harga  (Rp)</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Keluar</button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('backend.suratPesanan._form_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/surat-pesanan-detail.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/suratPesanan/detail.blade.php ENDPATH**/ ?>