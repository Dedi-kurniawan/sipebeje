<div class="btn-group">
    <a href="<?php echo e($edit); ?>" class="btn btn-success btn-sm">Step 1 <i class=" fas fa-arrow-right"></i></a>
    <a href="<?php echo e($step); ?>" class="btn btn-info btn-sm">Step 2 <i class=" fas fa-arrow-right"></i></a>
</div>
<br>
<div class="btn-group">
    <a href="<?php echo e($show); ?>" class="btn btn-info btn-sm mb-2"><i class="fa fa-list"></i> Detail</a>
    <button id="deleteData" data-id="<?php echo e($id); ?>" data-name="<?php echo e($name); ?>" class="btn btn-sm btn-outline-danger mb-2">
        <i class="fa fa-trash"></i> Hapus
    </button>
</div>

<?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/layouts/backend/partials/action/paket.blade.php ENDPATH**/ ?>