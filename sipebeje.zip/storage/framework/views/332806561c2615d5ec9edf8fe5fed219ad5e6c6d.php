
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form class="d-flex flex-wrap align-items-center">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="inputPassword2" class="visually-hidden">Search</label>
                                <div class="me-3">
                                    <label for="status-select" class="me-2">Nama</label>
                                    <input type="search" class="form-control my-1 my-md-0" id="nama_filter" placeholder="Nama...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="me-sm-3">
                                    <label for="status-select" class="me-2">Kecamatan</label>
                                    <select class="form-select my-1 my-md-0 select_filter" id="kecamatan_filter">
                                        <option value="">SEMUA KECAMATAN</option>
                                        <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="me-sm-3">
                                    <label for="status-select" class="me-2">Desa</label>
                                    <select class="form-select my-1 my-md-0 select_filter" id="desa_filter">
                                        <option value="">SEMUA DESA</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label for=""></label>
                                <div class="text-md-start">
                                    <button type="button" class="btn btn-danger waves-effect waves-light" id="button_filter"><i class="fa fa-search me-1"></i> Cari</button>
                                </div>
                            </div>
                        </div> 
                    </div>
                </form>
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if($akses['role'] == "admin" || $akses['role'] == "kabupaten"): ?>
                        <a href="<?php echo e(route('admin.vendor.create')); ?>" class="btn btn-sm btn-blue waves-effect waves-light float-end">
                            <i class="mdi mdi-plus-circle"></i> Data Baru
                        </a>
                    <?php endif; ?>
                    <h4 class="header-title">Menampilkan Data <?php echo e($bread['second']); ?></h4>
                    <p class="text-muted font-13 mb-4">
                        Total : <span id="total_data"></span> <?php echo e($bread['second']); ?></span>
                    </p>
                    <table id="datatable" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>DESA</th>
                                <th>NAMA</th>
                                <th>NPWP</th>
                                <th>TELEPON</th>
                                <th>ALAMAT</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/vendor.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sipebeje\resources\views/backend/vendor/index.blade.php ENDPATH**/ ?>