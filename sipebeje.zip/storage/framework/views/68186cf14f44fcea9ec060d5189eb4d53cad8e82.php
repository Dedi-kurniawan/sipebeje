<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>SIPEBEJE | <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="SIPEBEJE" name="description" />
        <meta content="SIPEBEJE" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="<?php echo e(asset('template/images/logo/favicon.ico')); ?>">
        <link href="<?php echo e(asset('backend/libs/jquery-toast-plugin/jquery.toast.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('backend/css/config/default/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
        <link href="<?php echo e(asset('backend/css/config/default/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-default-stylesheet" />
        <link href="<?php echo e(asset('backend/css/config/default/bootstrap-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
        <link href="<?php echo e(asset('backend/css/config/default/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="app-dark-stylesheet" />
        <link href="<?php echo e(asset('backend/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    </head>
    <body class="loading authentication-bg authentication-bg-pattern">
        <?php echo $__env->yieldContent('content'); ?>
        <footer class="footer footer-alt">
            <script>document.write(new Date().getFullYear())</script> &copy; Dinas Pemberdayaan Masyarakat dan Desa <a href="">Bengkulu Utara</a> 
        </footer>
        <script src="<?php echo e(asset('backend/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/libs/jquery-toast-plugin/jquery.toast.min.js')); ?>"></script>     
        <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/js/jquery-validation/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('template/barangjasa/base.js')); ?>?<?php echo e(date('Ymdhis')); ?>"></script>  
        <?php echo $__env->yieldPushContent('scripts'); ?>     
    </body>
</html><?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/frontend/auth.blade.php ENDPATH**/ ?>