<button id="editData" data-id="<?php echo e($id); ?>" data-name="<?php echo e($name); ?>" class="btn btn-sm btn-outline-success">
    <i class="fa fa-pen"></i> Ubah
</button>
<button id="deleteData" data-id="<?php echo e($id); ?>" data-name="<?php echo e($name); ?>" class="btn btn-sm btn-outline-danger">
    <i class="fa fa-trash"></i> Hapus
</button><?php /**PATH C:\laragon\www\sipebeje\resources\views/layouts/backend/partials/action/default.blade.php ENDPATH**/ ?>