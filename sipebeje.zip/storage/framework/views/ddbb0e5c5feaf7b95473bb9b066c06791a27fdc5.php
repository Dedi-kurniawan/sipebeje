
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Dashboard</h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header bg-primary">SIPEBEJE</div>
                <div class="card-body">
                    <h4 class="card-title text-white">Sistem Informasi Pengadaan Barang & Jasa Desa</h4>
                    <p class="card-text">Pengadaan Barang & Jasa secara Elektronik melalui sistem Informasi yang di akses secara daring oleh Penyedia, Pemerintah Desa & Dinas PMD</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('backend/libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/libs/selectize/css/selectize.bootstrap3.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/libs/selectize/js/standalone/selectize.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/pages/dashboard-1.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/dashboard/index.blade.php ENDPATH**/ ?>