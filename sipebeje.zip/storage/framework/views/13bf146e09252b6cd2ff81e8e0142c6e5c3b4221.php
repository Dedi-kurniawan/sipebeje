
<?php $__env->startSection('title', $bread['second']); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($bread['first']); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e($bread['url']); ?>"><?php echo e($bread['second']); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($bread['third']); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($bread['first']); ?></h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <form class="d-flex flex-wrap align-items-center">
                            <div class="col-5">
                                <input type="search" class="form-control" id="search_filter" placeholder="Search...">
                            </div>
                            <div class="col-4">
                                <select class="form-select select_filter my-2" id="desa_filter">
                                    <option value="">Semua</option>
                                    <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($x->id); ?>" <?php echo e($x->id == $desaId ? 'selected' : ''); ?>><?php echo e($x->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-3">
                                &nbsp;
                                <button type="button" class="btn btn-blue waves-effect waves-light mx-2" id="button_filter">
                                    <i class="mdi mdi-account-search"></i> Cari
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if(Auth::user()->role == 'desa'): ?>
                        <button type="button" class="btn btn-sm btn-blue waves-effect waves-light float-end" id="createData" onclick="createData()">
                            <i class="mdi mdi-plus-circle"></i> Berita Acara Serah Terima Pekerjaan Baru
                        </button>
                    <?php endif; ?>
                    <h4 class="header-title">Menampilkan Data <?php echo e($bread['second']); ?></h4>
                    <p class="text-muted font-13 mb-4">
                        Total : <span id="total_data"></span> <?php echo e($bread['second']); ?></span>
                    </p>
                    <table id="datatable" class="table dt-responsive w-100">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>TANGGAL</th>
                                <th>NOMOR</th>
                                <th>PAKET</th>
                                <th>DESA</th>
                                <th>KETUA TPK</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody class="text-uppercase"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('backend.baPekerjaan._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('template/barangjasa/admin/ba-pekerjaan.js')); ?>?<?php echo e(date('ymdshi')); ?>"></script>
<?php if($errors->any()): ?>
<script type="text/javascript">
     $(window).on('load', function() {
        $('#formModal').modal('show');
    });
</script>
<?php endif; ?>
<?php echo $__env->make('layouts.frontend.partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/baPekerjaan/index.blade.php ENDPATH**/ ?>