<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>STEP PERTAMA</title>
    <style>
        body {
            font-family: "Arial Narrow", Times, serif;
            /* font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;  */
            font-size: 12px;
            margin: 0cm 2cm 2cm 2cm;
        }

        .kop-surat {
            text-align: center;
        }

        .lineup {
            border-bottom: 3px solid black;
            margin-top: 1px;
        }

        .linebottom {
            border-bottom: 1px solid black;
            margin-top: 1px;
        }

        .title-one {
            font-size: 16px;
            margin-bottom: 0.5px;
        }

        .title-two {
            text-align: center;
            font-size: 16px;
        }

        .text-uppercase {
            text-transform: uppercase;
        }

        .text-bold {
            font-weight: bold;
        }

        .text-right {
            text-align: right;
        }

        .text-left {
            text-align: left;
        }

        .text-center {
            text-align: center;
        }

        .table-material table,
        .table-border {
            border: 1px solid black;
            border-collapse: collapse;
        }

        .page-break {
            page-break-after: always;
        }

        .f-12 {
            font-size: 12px;
        }

        .table-bordered {
            width: 100%;
            border: 1px solid black;
            border-collapse: collapse;
        }

        .table-bordered tr td {
            border: 1px solid black;
            border-collapse: collapse;
            text-align: center;
        }

    </style>
</head>
<body>
    <div class="akk text-uppercase">
        <table width="100%">
            <tr>
                <td>
                    <img alt="Logo" src="<?php echo e(asset('template/images/logo/logo-sm.png')); ?>" class="text-right" align="bottom" width="70" height="80" />
                </td>
                <td class="text-center text-bold">
                    <div class="kop-surat">
                        <div>PEMERINTAH KABUPATEN BENGKULU UTARA </div>
                        <div class="text-bold">KECAMATAN <?php echo e($paket->kecamatan->nama); ?></div>
                        <div><?php echo e($paket->desa->nama); ?> - Kabupaten Bengkulu Utara</div>
                    </div>
                </td>
            </tr>
        </table>
        <div class="kop-surat">
            <div class="lineup"></div>
            <div class="linebottom"></div>
        </div>
    </div>
    <br>
    <div class="akk text-uppercase">
        <div class="f-11">
            <div class="text-center">
                <span class="text-bold">KERANGKA ACUAN KERJA (KAK)</span><br>
                <span class="text-bold text-uppercase">KEGIATAN <?php echo e($paket->akk->kegiatan); ?> <br>
                    DUSUN <?php echo e($paket->akk->dusun); ?> RT <?php echo e($paket->akk->rt); ?>

                </span>
            </div>
            <br>
            <span class="text-bold">I. LATAR BELAKANG.</span><br>
            <div>
                <span style="text-align: justify;">
                    <?php echo e($paket->akk->latar_belakang); ?>

                </span>
            </div>
            <br>
            <span class="text-bold">II. MAKSUD DAN TUJUAN</span>
            <div>
                <span class="text-bold">Maksud :</span><br>
                <span><?php echo e($paket->akk->maksud); ?></span><br><br>
                <span class="text-bold">Tujuan :</span><br>
                <span><?php echo e($paket->akk->tujuan); ?></span>
            </div>
            <br>
            <span class="text-bold">III. HASIL YANG DIHARAPKAN</span>
            <div>
                <span><?php echo e($paket->akk->hasil); ?></span>
            </div>
            <br>
            <span class="text-bold">IV. LOKASI KEGIATAN</span>
            <div>
                <span style="text-align: justify;"><?php echo e($paket->akk->lokasi_kegiatan); ?></span>
            </div>
            <br>
            <span class="text-bold">V. DASAR PENGANGGARAN</span>
            <div>
                <span style="text-align: justify;"><?php echo e($paket->akk->dasar_penganggaran); ?> NO
                    <?php echo e($paket->akk->dp_no); ?>

                    TGL
                    <?php echo e($paket->akk->dp_tgl); ?> BIDANG <?php echo e($paket->akk->dp_bidang); ?> SUB BIDANG
                    <?php echo e($paket->akk->dp_subbidang); ?> KEGIATAN <?php echo e($paket->akk->dp_kegiatan); ?></span>
            </div>
            <br>
            <span class="text-bold">VI. JANGKA WAKTU PELAKSANAAN</span>
            <div>
                <span style="text-align: justify;"><?php echo e($paket->akk->kegiatan); ?> YAITU SELAMA
                    <?php echo e($paket->akk->waktu_pelaksanaan); ?> HARI</span>
            </div>
            <br>
            <span class="text-bold">VII. GAMBARAN PELAKSANAAN KEGIATAN</span>
            <div>
                <span style="text-align: justify;"><?php echo $paket->akk->gambaran_pelaksanaan; ?></span>
            </div>
            <br>
            <span class="text-bold">VIII. SPESIFIKASI TEKNIS (TERLAMPIR)</span>
            <div>
                <span style="text-align: justify;"><?php echo $paket->akk->spesifikasi_teknis; ?></span>
            </div>
            <br>
            <span class="text-bold">IX. DAFTAR TENAGA KERJA DARI DESA </span>
            <div>
                <span style="text-align: justify;"><?php echo $paket->akk->tenaga_kerja; ?></span>
            </div>
            <br>
            <span class="text-bold">X. METODE PENGADAAN</span>
            <div>
                <span style="text-align: justify;"><?php echo $paket->akk->metode_pengadaan; ?></span>
            </div>
            <br>
            <span class="text-bold">XI. PAGU ANGGARAN</span>
            <div>
                <span style="text-align: justify;"><?php echo e($paket->akk->pagu_anggaran); ?> ADALAH Rp.
                    <?php echo e(number_format($paket->akk->pagu_anggaran_rp,2,',','.')); ?>

                    (<?php echo e($paket->akk->pagu_anggaran_terbilang); ?>)</span>
            </div>
        </div>
    </div>
    <br>
    <div style="float: right;">
        <table>
            <tr>
                <td><?php echo e(ucwords(strtolower($paket->desa->nama))); ?>, <?php echo e($paket->akk->CreatedAtFormat); ?></td>
            </tr>
            <tr>
                <td>PELAKSANA KEGIATAN</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td class="text-center"><?php echo e(ucwords(strtolower($paket->aparatur->nama))); ?></td>
            </tr>
        </table>
    </div>
    <div class="page-break"></div>

    
</div>
<br>
<div class="akk text-uppercase">
    <table width="100%">
        <tr>
            <td>
                <img alt="Logo" src="<?php echo e(asset('template/images/logo/logo-sm.png')); ?>" class="text-right" align="bottom" width="70" height="80" />
            </td>
            <td class="text-center text-bold">
                <div class="kop-surat">
                    <div>PEMERINTAH KABUPATEN BENGKULU UTARA </div>
                    <div class="text-bold">KECAMATAN <?php echo e($paket->kecamatan->nama); ?></div>
                    <div><?php echo e($paket->desa->nama); ?> - Kabupaten Bengkulu Utara</div>
                </div>
            </td>
        </tr>
    </table>
    <div class="kop-surat">
        <div class="lineup"></div>
        <div class="linebottom"></div>
    </div>
</div>
<br>
<div class="f-11">
    <div class="text-center">
        <span class="text-bold">HARGA PERKIRAAN SENDIRI (HPS)</span><br>
        <span class="text-bold text-uppercase">KEGIATAN <?php echo e($paket->akk->kegiatan); ?> <br>
            DUSUN <?php echo e($paket->akk->dusun); ?> RT <?php echo e($paket->akk->rt); ?>

        </span>
    </div>
    <br>
    <table class="table-bordered">
        <tr class="text-bold">
            <td>NO</td>
            <td>URAIAN</td>
            <td>VOLUME</td>
            <td>SATUAN</td>
            <td>HARGA SATUAN</td>
            <td>JUMLAH</td>
            <td>PAJAK</td>
            <td>TOTAL (Jumlah + Pajak)</td>
        </tr>
        <?php
                $total = 0;
            ?>
            <?php $__currentLoopData = $paket->hpsTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                 $total += ($hps->jumlah + $hps->harga_pajak);
            ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($hps->uraian); ?></td>
                    <td><?php echo e($hps->volume); ?></td>
                    <td><?php echo e($hps->satuan); ?></td>
                    <td><?php echo e(number_format($hps->harga_satuan,2,',','.')); ?></td>
                    <td><?php echo e(number_format($hps->jumlah,2,',','.')); ?></td>
                    <td><?php echo e($hps->pajak); ?> %</td>
                    <td><?php echo e(number_format($hps->jumlah + $hps->harga_pajak,2,',','.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="6" class="text-bold">TOTAL</td>
                <td colspan="2">Rp <?php echo e(number_format($total,2,',','.')); ?></td>
            </tr>
    </table>
</div>
<br>
<div style="float: right;">
    <table>
        <tr>
            <td><?php echo e(ucwords(strtolower($paket->desa->nama))); ?>, <?php echo e($paket->akk->CreatedAtFormat); ?></td>
        </tr>
        <tr>
            <td>PELAKSANA KEGIATAN</td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td class="text-center"><?php echo e(ucwords(strtolower($paket->aparatur->nama))); ?></td>
        </tr>
    </table>
</div>
</body>

</html>
<?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/paket/cetak/step_pertama_print.blade.php ENDPATH**/ ?>