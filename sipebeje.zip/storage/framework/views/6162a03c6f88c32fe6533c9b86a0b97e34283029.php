<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>SURAT PESANAN</title>
    <style>
        body {
            font-family: "Arial Narrow", Times, serif;
            /* font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;  */
            font-size: 12px;
            margin: 0cm 2cm 2cm 2cm;
        }

        .kop-surat {
            text-align: center;
        }

        .lineup {
            border-bottom: 3px solid black;
            margin-top: 1px;
        }

        .linebottom {
            border-bottom: 1px solid black;
            margin-top: 1px;
        }

        .title-one {
            font-size: 16px;
            margin-bottom: 0.5px;
        }

        .title-two {
            text-align: center;
            font-size: 16px;
        }

        .text-uppercase {
            text-transform: uppercase;
        }

        .text-bold {
            font-weight: bold;
        }

        .text-right {
            text-align: right;
        }

        .text-left {
            text-align: left;
        }

        .text-center {
            text-align: center;
        }

        .table-material table,
        .table-border {
            border: 1px solid black;
            border-collapse: collapse;
        }

        .page-break {
            page-break-after: always;
        }

        .f-12 {
            font-size: 12px;
        }
        .f-14 {
            font-size: 14px;
        }
        .table-bordered {
            width: 100%;
            border: 1px solid black;
            border-collapse: collapse;
        }

        .table-bordered tr td {
            border: 1px solid black;
            border-collapse: collapse;
        }

    </style>
</head>
<body>
<div class="akk">
    <table width="100%">
        <tr>
            <td>
                <img alt="Logo" src="<?php echo e(asset('template/images/logo/logo-sm.png')); ?>" class="text-right" align="bottom" width="70" height="80" />
            </td>
            <td class="text-center text-bold text-uppercase">
                <div class="kop-surat">
                    <div>PEMERINTAH KABUPATEN BENGKULU UTARA </div>
                    <div class="text-bold">KECAMATAN <?php echo e(strtoupper($sp->kecamatan)); ?></div>
                    <div><?php echo e($sp->alamat_desa); ?> - Kabupaten Bengkulu Utara</div>
                </div>
            </td>
        </tr>
    </table>
    <div class="kop-surat">
        <div class="lineup"></div>
        <div class="linebottom"></div>
    </div>
</div>
<br>
<div class="text-center f-12">
    <strong><u>SURAT PESANAN</u></strong><br/>
    <strong>Nomor: <?php echo e($sp->nomor_surat); ?></strong>
</div>
<p><?php echo e($sp->tanggal_text); ?>, kami yang bertanda tangan dibawah ini :</p>
<table style="margin-left: -2px">
    <tr>
        <td>Nama</td>
        <td>:</td>
        <td><strong><?php echo e($sp->nama_aparatur); ?></strong></td>
    </tr>
    <tr>
        <td>Jabatan</td>
        <td>:</td>
        <td>Ketua Tim Pengelola Kegiatan</td>
    </tr>
    
</table>
<table>
    <tr>
        <td>selanjutnya disebut sebagai KETUA TPK</td>
    </tr>
</table>
<br>
<table style="margin-left: -2px">
    <tr>
        <td>Nama</td>
        <td>:</td>
        <td><strong><?php echo e($sp->nama_pimpinan_toko); ?></strong></td>
    </tr>
    <tr>
        <td>Jabatan</td>
        <td>:</td>
        <td>Pimpinan Toko <?php echo e($sp->nama_vendor); ?></td>
    </tr>
    <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><?php echo e($sp->alamat_vendor); ?></td>
    </tr>
</table>
<table>
    <tr>
        <td>selanjutnya disebut sebagai PENYEDIA ;</td>
    </tr>
</table>
<p>
    Untuk mengirimkan Barang dengan memperhatikan ketentuan - ketentuan sebagai Berikut : <br>
    1. Rincian Barang
</p>
<div class="f-11">
    <table class="table-bordered">
        <tr class="text-center">
            <td>No</td>
            <td>Uraian Barang</td>
            <td>Volume</td>
            <td>Satuan</td>
            <td>SP</td>
            <td>Total  Harga  (Rp)</td>
        </tr>
        <?php $total = 0 ?>
        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e(ucwords(strtolower($x->uraian))); ?></td>
                <td class="text-right"><?php echo e($x->volume); ?></td>
                <td class="text-center"><?php echo e($x->satuan); ?></td>
                <td class="text-right"><?php echo e(number_format($x->harga_satuan, 2)); ?></td>
                <td class="text-right"><?php echo e(number_format($x->volume * $x->harga_satuan, 2)); ?></td>
            </tr>
        <?php $total += ($x->volume * $x->harga_satuan) ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php
            $ppn = 0;
            if($sp->ppn > 0) {
                $ppn = $total + ($total * $sp->ppn) / 100;
            }

            $pph = 0;
            if($sp->pph > 0) {
                $pph = $total + ($total * $sp->pph) / 100;
            }
        ?>
        <tr>
            <td colspan="5" class="text-center">Jumlah setelah pajak</td>
            <td class="text-right"><?php echo e(number_format($total, 2)); ?></td>
        </tr>
        <tr>
            <td colspan="5" class="text-center">PPN</td>
            <td class="text-right">
                <?php if($sp->ppn != 0): ?>
                    <?php echo e($sp->ppn); ?>%
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td colspan="5" class="text-center">PPH. 23</td>
            <td class="text-right">
                <?php if($sp->pph != 0): ?>
                    <?php echo e($sp->pph); ?>%
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td colspan="5" class="text-center">Jumlah sebelum pajak</td>
            <td class="text-right"><?php echo e(number_format($total + $ppn + $pph, 2)); ?></td>
        </tr>
    </table>
</div>
<br>
<table style="margin-left: -2px; width: 100%">
    <tr>
        <td>2.</td>
        <td colspan="3">Tanggal barang diterima paling</td>
    </tr>
    <tr>
        <td></td>
        <td>lambat tanggal</td>
        <td style="width: 5px">:</td>
        <td><?php echo e($sp->tanggal_lambat_text); ?></td>
    </tr>
    <tr>
        <td>3.</td>
        <td>Dibebankan Kepada</td>
        <td style="width: 5px">:</td>
        <td>Bidang Pelaksanaan Pembangunan Desa Kegiatan  Dukungan Pembinaan dan Keagamaan</td>
    </tr>
    <tr>
        <td>4.</td>
        <td>Jenis Belanja</td>
        <td style="width: 5px">:</td>
        <td>Belanja Barang dan Jasa</td>
    </tr>
    <tr>
        <td>5.</td>
        <td>Uraian rincian Jenis Belanja</td>
        <td>:</td>
        <td><?php echo e($sp->uraian); ?></td>
    </tr>
    <tr>
        <td>6.</td>
        <td colspan="3">Pembayaran akan dibatalkan apabila barang tersebut tidak sesuai dengan pesanan (order)</td>
    </tr>
    <tr>
        <td>7.</td>
        <td colspan="3">Pembayaran dilakukan setelah barang diterima dengan jumlah yang cukup dan dalam  keadaan baik</td>
    </tr>
    <tr>
        <td>8.</td>
        <td colspan="3">
            Pesanan/Order akan batal  bila pada tanggal yang ditentukan melewati batas waktu yang ditentukan <br>
        </td>
    </tr>
    <tr>
        <td></td>
        <td colspan="3">Alamat pengiriman barang pada Kantor Desa <?php echo e(ucwords(strtolower($sp->nama_desa))); ?>

        </td>
    </tr>
</table>

<table style="width:100%">
    <tr>
        <td class="text-center" style="width: 50%">
            <p>
                &nbsp;<br>
                <strong>Menerima Pesanan</strong> <br>
            </p>
        </td>
        <td class="text-center" style="width: 50%">
            <p>
                <span><?php echo e(ucwords(strtolower($sp->nama_desa))); ?>, <?php echo e(strtoupper($sp->tanggal)); ?></span><br>
                <strong>Untuk dan atas nama Ketua</strong> <br>
                Tim Pengelola Kegiatan
            </p>
        </td>
    </tr>
    <tr>
        <td><br><br></td>
        <td><br><br></td>
    </tr>
    <tr>
        <td class="text-center">
            <p>
                <strong><u><?php echo e(strtoupper($sp->nama_pimpinan_toko)); ?></u></strong><br/>
                Pimpinan Toko
            </p>
        </td>
        <td class="text-center">
            <strong><?php echo e(strtoupper($sp->nama_aparatur)); ?></strong><br/>&nbsp;
        </td>
    </tr>
</table>
</body>
</html>
<?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/backend/suratPesanan/cetak.blade.php ENDPATH**/ ?>