<ul id="side-menu">
    <li class="menu-title">MAIN MENU</li>  
    <li>
        <a href="<?php echo e(route('admin.dashboard.index')); ?>">
            <i data-feather="airplay"></i>
            <span> Dashboard</span>
        </a>
    </li>
    
    <li>
        <a href="<?php echo e(route('admin.undangan.paket')); ?>">
            <i data-feather="send"></i>
            <span>Undangan</span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.profile.vendor')); ?>">
            <i data-feather="bar-chart-2"></i>
            <span>Profile Perusahaan</span>
        </a>
    </li>
</ul><?php /**PATH /home/kepegaw3/sipebeje.web.id/resources/views/layouts/backend/partials/menu/vendor.blade.php ENDPATH**/ ?>